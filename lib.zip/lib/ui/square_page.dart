
import 'package:flutter/material.dart';

class SquarePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _SquarePage();
  }
}

class _SquarePage extends State<SquarePage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('squarepage'),
    );
  }
}
