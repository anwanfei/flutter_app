import 'package:flutter/material.dart';

class KnowlegePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _KnowlegePage();
  }
}

class _KnowlegePage extends State<KnowlegePage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('knowlegepage'),
    );
  }
}
