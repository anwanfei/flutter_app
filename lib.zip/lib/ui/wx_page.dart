import 'package:flutter/material.dart';

class WxPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _WxPage();
  }
}

class _WxPage extends State<WxPage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('wxpage'),
    );
  }
}
