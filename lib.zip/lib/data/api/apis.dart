///接口类
class Apis {
  static const String BASE_HOST = "https://www.wanandroid.com";

  /// 首页轮播
  static const String HOME_BANNER = BASE_HOST + "/banner/json";
}
